set(OPTION_DEFAULT ON)
set(OPTION_CLIENT_DEFAULT ON)
set(OPTION_SERVER_DEFAULT ON)

if(ANDROID)
  set(OPTION_SERVER_DEFAULT OFF)
endif()

define_channel_options(
  NAME
  "audin"
  TYPE
  "dynamic"
  DESCRIPTION
  "Audio Input Redirection Virtual Channel Extension"
  SPECIFICATIONS
  "[MS-RDPEAI]"
  DEFAULT
  ${OPTION_DEFAULT}
  CLIENT_DEFAULT
  ${OPTION_CLIENT_DEFAULT}
  SERVER_DEFAULT
  ${OPTION_SERVER_DEFAULT}
)
