/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Audio Output Virtual Channel
 *
 * Copyright 2019 Armin Novak <armin.novak@thincast.com>
 * Copyright 2019 Thincast Technologies GmbH
 * Copyright 2020 Ingo Feinerer <feinerer@logic.at>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <freerdp/config.h>

#include <sndio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <winpr/crt.h>
#include <winpr/stream.h>
#include <winpr/cmdline.h>

#include <freerdp/types.h>

#include "rdpsnd_main.h"

typedef struct
{
	rdpsndDevicePlugin device;

	struct sio_hdl* hdl;
	struct sio_par par;
} rdpsndSndioPlugin;

static BOOL rdpsnd_sndio_open(rdpsndDevicePlugin* device, const AUDIO_FORMAT* format,
                              WINPR_ATTR_UNUSED UINT32 latency)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;

	if (device == nullptr || format == nullptr)
		return FALSE;

	if (sndio->hdl != nullptr)
		return TRUE;

	sndio->hdl = sio_open(SIO_DEVANY, SIO_PLAY, 0);
	if (sndio->hdl == nullptr)
	{
		WLog_ERR(TAG, "could not open audio device");
		return FALSE;
	}

	sio_initpar(&sndio->par);
	sndio->par.bits = format->wBitsPerSample;
	sndio->par.pchan = format->nChannels;
	sndio->par.rate = format->nSamplesPerSec;
	if (!sio_setpar(sndio->hdl, &sndio->par))
	{
		WLog_ERR(TAG, "could not set audio parameters");
		return FALSE;
	}
	if (!sio_getpar(sndio->hdl, &sndio->par))
	{
		WLog_ERR(TAG, "could not get audio parameters");
		return FALSE;
	}

	if (!sio_start(sndio->hdl))
	{
		WLog_ERR(TAG, "could not start audio device");
		return FALSE;
	}

	return TRUE;
}

static void rdpsnd_sndio_close(rdpsndDevicePlugin* device)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;

	if (device == nullptr)
		return;

	if (sndio->hdl != nullptr)
	{
		sio_stop(sndio->hdl);
		sio_close(sndio->hdl);
		sndio->hdl = nullptr;
	}
}

static BOOL rdpsnd_sndio_set_volume(rdpsndDevicePlugin* device, UINT32 value)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;

	if (device == nullptr || sndio->hdl == nullptr)
		return FALSE;

	/*
	 * Low-order word contains the left-channel volume setting.
	 * We ignore the right-channel volume setting in the high-order word.
	 */
	return sio_setvol(sndio->hdl, ((value & 0xFFFF) * SIO_MAXVOL) / 0xFFFF);
}

static void rdpsnd_sndio_free(rdpsndDevicePlugin* device)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;

	if (device == nullptr)
		return;

	rdpsnd_sndio_close(device);
	free(sndio);
}

static BOOL rdpsnd_sndio_format_supported(WINPR_ATTR_UNUSED rdpsndDevicePlugin* device,
                                          const AUDIO_FORMAT* format)
{
	if (format == nullptr)
		return FALSE;

	return (format->wFormatTag == WAVE_FORMAT_PCM);
}

static UINT rdpsnd_sndio_play(rdpsndDevicePlugin* device, const BYTE* data, size_t size)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;

	if (device == nullptr || sndio->hdl == nullptr)
		return ERROR_INVALID_PARAMETER;

	const size_t rc = sio_write(sndio->hdl, data, size);
	if (rc != size)
		return CHANNEL_RC_OK;
	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpsnd_sndio_parse_addin_args(rdpsndDevicePlugin* device, const ADDIN_ARGV* args)
{
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)device;
	WINPR_ASSERT(sndio);

	COMMAND_LINE_ARGUMENT_A rdpsnd_sndio_args[] = { { nullptr, 0, nullptr, nullptr, nullptr, -1,
		                                              nullptr, nullptr } };
	const DWORD flags =
	    COMMAND_LINE_SIGIL_NONE | COMMAND_LINE_SEPARATOR_COLON | COMMAND_LINE_IGN_UNKNOWN_KEYWORD;
	const int status = CommandLineParseArgumentsA(args->argc, args->argv, rdpsnd_sndio_args, flags,
	                                              sndio, nullptr, nullptr);

	if (status < 0)
		return ERROR_INVALID_DATA;

	const COMMAND_LINE_ARGUMENT_A* arg = rdpsnd_sndio_args;

	do
	{
		if (!(arg->Flags & COMMAND_LINE_VALUE_PRESENT))
			continue;

		CommandLineSwitchStart(arg) CommandLineSwitchEnd(arg)
	} while ((arg = CommandLineFindNextArgumentA(arg)) != nullptr);

	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
FREERDP_ENTRY_POINT(UINT VCAPITYPE sndio_freerdp_rdpsnd_client_subsystem_entry(
    PFREERDP_RDPSND_DEVICE_ENTRY_POINTS pEntryPoints))
{
	UINT ret = CHANNEL_RC_OK;
	rdpsndSndioPlugin* sndio = (rdpsndSndioPlugin*)calloc(1, sizeof(rdpsndSndioPlugin));

	if (sndio == nullptr)
		return CHANNEL_RC_NO_MEMORY;

	sndio->device.Open = rdpsnd_sndio_open;
	sndio->device.FormatSupported = rdpsnd_sndio_format_supported;
	sndio->device.SetVolume = rdpsnd_sndio_set_volume;
	sndio->device.Play = rdpsnd_sndio_play;
	sndio->device.Close = rdpsnd_sndio_close;
	sndio->device.Free = rdpsnd_sndio_free;
	const ADDIN_ARGV* args = pEntryPoints->args;

	if (args->argc > 1)
	{
		ret = rdpsnd_sndio_parse_addin_args(&sndio->device, args);

		if (ret != CHANNEL_RC_OK)
		{
			WLog_ERR(TAG, "error parsing arguments");
			goto error;
		}
	}

	pEntryPoints->pRegisterRdpsndDevice(pEntryPoints->rdpsnd, &sndio->device);
	return ret;
error:
	rdpsnd_sndio_free(&sndio->device);
	return ret;
}
