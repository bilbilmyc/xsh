set(OPTION_DEFAULT ON)
set(OPTION_CLIENT_DEFAULT OFF)
set(OPTION_SERVER_DEFAULT ON)

define_channel_options(
  NAME
  "rdpemsc"
  TYPE
  "dynamic"
  DESCRIPTION
  "Mouse Cursor Virtual Channel Extension"
  SPECIFICATIONS
  "[MS-RDPEMSC]"
  DEFAULT
  ${OPTION_DEFAULT}
  CLIENT_DEFAULT
  ${OPTION_CLIENT_DEFAULT}
  SERVER_DEFAULT
  ${OPTION_SERVER_DEFAULT}
)
