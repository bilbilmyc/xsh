set(OPTION_DEFAULT ON)
set(OPTION_CLIENT_DEFAULT ON)
set(OPTION_SERVER_DEFAULT ON)

define_channel_options(
  NAME
  "rail"
  TYPE
  "static"
  DESCRIPTION
  "Remote Programs Virtual Channel Extension"
  SPECIFICATIONS
  "[MS-RDPERP]"
  DEFAULT
  ${OPTION_DEFAULT}
  CLIENT_DEFAULT
  ${OPTION_CLIENT_DEFAULT}
  SERVER_DEFAULT
  ${OPTION_SERVER_DEFAULT}
)
