set(OPTION_DEFAULT ON)
set(OPTION_CLIENT_DEFAULT ON)
set(OPTION_SERVER_DEFAULT OFF)

define_channel_options(
  NAME
  "video"
  TYPE
  "dynamic"
  DESCRIPTION
  "Video optimized remoting Virtual Channel Extension"
  SPECIFICATIONS
  "[MS-RDPEVOR]"
  DEFAULT
  ${OPTION_DEFAULT}
  CLIENT_DEFAULT
  ${OPTION_CLIENT_DEFAULT}
  SERVER_DEFAULT
  ${OPTION_SERVER_DEFAULT}
)
