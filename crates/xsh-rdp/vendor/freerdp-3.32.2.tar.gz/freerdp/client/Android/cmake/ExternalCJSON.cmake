include(ExternalProject)
include(DepVersions)

ExternalProject_Add(
  cjson DOWNLOAD_EXTRACT_TIMESTAMP OFF SOURCE_DIR ${CMAKE_SOURCE_DIR}/external/cjson
  URL https://github.com/DaveGamble/cJSON/archive/refs/tags/${CJSON_VERSION}.tar.gz URL_HASH ${CJSON_HASH}
  LIST_SEPARATOR | CMAKE_ARGS ${ANDROID_CMAKE_ARGS} -DENABLE_CJSON_TEST:BOOL=OFF -DENABLE_HIDDEN_SYMBOLS:BOOL=OFF
                              -DENABLE_CJSON_UNINSTALL:BOOL=OFF -DCMAKE_POLICY_VERSION_MINIMUM:STRING=3.5
)
