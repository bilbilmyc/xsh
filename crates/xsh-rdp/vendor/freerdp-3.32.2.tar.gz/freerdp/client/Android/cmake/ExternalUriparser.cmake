include(ExternalProject)
include(DepVersions)

ExternalProject_Add(
  uriparser
  DOWNLOAD_EXTRACT_TIMESTAMP OFF
  SOURCE_DIR ${CMAKE_SOURCE_DIR}/external/uriparser
  URL https://github.com/uriparser/uriparser/releases/download/uriparser-${URIPARSER_VERSION}/uriparser-${URIPARSER_VERSION}.tar.xz
  URL_HASH ${URIPARSER_HASH}
  LIST_SEPARATOR |
  CMAKE_ARGS ${ANDROID_CMAKE_ARGS} -DURIPARSER_BUILD_DOCS:BOOL=OFF -DURIPARSER_BUILD_TESTS:BOOL=OFF
             -DURIPARSER_BUILD_TOOLS:BOOL=OFF
)
